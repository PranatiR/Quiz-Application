const express = require("express");
const mdb = require("mongoose");
const bcrypt = require("bcrypt");
const dotenv = require("dotenv");
const jwt = require("jsonwebtoken");
const cors = require("cors");
const axios = require("axios");
const User=require("./models/User");
const QuizResult=require("./models/quizResults")


const app = express();
app.use(express.json());
app.use(cors());
dotenv.config();

mdb.connect(process.env.mongourl)
    .then(() => console.log("DB connected successfully!"))
    .catch((err) => {
        console.error("Couldn't connect to DB:", err);
        process.exit(1);
    });

app.post("/signup", async (req, res) => {
    console.log('Received signup request:', req.body);
    const { email, password } = req.body;

    if (!email || !password) {
        console.log('Missing required fields');
        return res.status(400).json({ 
            message: "All fields are required",
            isvalid: false,
            details: { email: !email, password: !password }
        });
    }

    try {
        console.log('Checking for existing user with email:', email);
        const existingUser = await User.findOne({ email });
        
        if (existingUser) {
            console.log('User already exists with email:', email);
            return res.status(400).json({ 
                message: "Email already exists",
                isvalid: false
            });
        }

        console.log('Creating new user...');
        const salt = await bcrypt.genSalt(10);
        const hashedPassword = await bcrypt.hash(password, salt);

        const newUser = new User({ 
            email, 
            password: hashedPassword,
            clicks: 0,
            score: 0
        });

        const savedUser = await newUser.save();
        console.log('User created successfully:', savedUser._id);

        return res.status(201).json({ 
            message: "User registered successfully", 
            isvalid: true,
            userId: savedUser._id
        });
    } catch (error) {
        console.error('Error in signup:', error);
        res.status(500).json({ 
            message: error.message || "Server error", 
            isvalid: false,
            error: process.env.NODE_ENV === 'development' ? error.toString() : undefined
        });
    }
});

// Update user clicks
app.post('/update-clicks', async (req, res) => {
    const { userId } = req.body;
    
    try {
        const user = await User.findById(userId);
        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }
        
        user.clicks += 1;
        await user.save();
        
        res.json({ clicks: user.clicks });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error' });
    }
});

app.post('/update-score', async (req, res) => {
    const { userId, score } = req.body;
    
    try {
        const user = await User.findById(userId);
        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }
        
        user.score = score;
        await user.save();
        
        res.json({ score: user.score });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error' });
    }
});

app.post("/login", async (req, res) => {
    const { email, password } = req.body;

    if (!email || !password) {
        return res.status(400).json({ message: "All fields are required" });
    }

    try {
        const user = await User.findOne({ email });
        if (!user) {
            return res.status(400).json({ message: "User not found", isvalid: false });
        }

        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            return res.status(401).json({ message: "Invalid credentials", isvalid: false });
        }

        // Generate JWT Token
        const token = jwt.sign({ userId: user._id }, process.env.SECRET_KEY, { expiresIn: "1h" });

        return res.status(200).json({
            message: "Login successful",
            token, 
            isvalid: true,
            user: { firstname: user.firstname, lastname: user.lastname, email: user.email }
        });

    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Server error", isvalid: false });
    }
});


app.post('/storeResult', async (req, res) => {
  try {
    const { email, category, score, totalQuestions } = req.body;

    const percentage = (score / totalQuestions) * 100;

    const newResult = new QuizResult({
      email,
      category,
      score,
      totalQuestions, 
      percentage
    });

    await newResult.save();
    res.status(201).json({ message: 'Quiz result saved successfully.',isvalid:true });
  } catch (err) {
    res.status(500).json({ error: 'Failed to save quiz result.' ,isvalid:true });
    console.log(err);
  }
});


app.get('/quiz-results', async (req, res) => {
  try {
    const { email } = req.query; 
    if (!email) return res.status(400).json({ error: 'Email is required' });

    const results = await QuizResult.find({ email }).sort({ date: -1 });
    return res.json(results);
  } catch (err) {
    console.error('Error fetching quiz results:', err);
    return res.status(500).json({ error: 'Failed to fetch quiz results' });
  }
});


const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`Server is running on port ${PORT}`));
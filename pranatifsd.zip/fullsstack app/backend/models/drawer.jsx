const AllScoresDrawer = ({ open, onClose, data }) => {
  return (
    <Drawer anchor="right" open={open} onClose={onClose}>
      <Box sx={{ width: 350, padding: 3 }}>
        <Typography variant="h6">All User Scores</Typography>
        {Object.entries(data).map(([email, scores]) => (
          <Box key={email} sx={{ mt: 2 }}>
            <Typography variant="subtitle1" sx={{ fontWeight: 'bold' }}>{email}</Typography>
            {scores.map((s, i) => (
              <Typography key={i} variant="body2">
                {s.category}: {s.score}/{s.totalQuestions} ({s.percentage.toFixed(1)}%)
              </Typography>
            ))}
          </Box>
        ))}
      </Box>
    </Drawer>
  );
};

export default AllScoresDrawer;
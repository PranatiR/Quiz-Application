import React, { useState } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios'
import {
  Container,
  Paper,
  Typography,
  TextField,
  Button,
  Box,
  Link as MuiLink,
} from '@mui/material';

export default function SignUp() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [passwordConfirm, setPasswordConfirm] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const { signup } = useAuth();
  const navigate = useNavigate();

  async function handleSubmit(e) {
    e.preventDefault();

    if (password !== passwordConfirm) {
      return setError('Passwords do not match');
    }

    try{
            const res= await axios.post("http://localhost:4000/signup",{
                email:email,
                password:password
            })
            console.log(res.data)
            if(res.data.isvalid){
                alert("account created Successfully!");
                navigate('/');
            }
            else{
                alert("account creation failed!")
            }
        }catch(err){
            console.log(err);
        }
    setLoading(false);
  }

  return (
    <Box
      sx={{
        minHeight: '100vh',
        display: 'flex',
        alignItems: 'center',
        background: `linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)), url('https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.freepik.com%2Ffree-vector%2Fquiz-background-with-flat-objects_1022603.htm&psig=AOvVaw2awps1Oh_SSa9k7rWETo1y&ust=1747329189596000&source=images&cd=vfe&opi=89978449&ved=0CBQQjRxqFwoTCIDtvc-6o40DFQAAAAAdAAAAABAE')`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
      }}
    >
      <Container maxWidth="sm">
        <Paper 
          elevation={5}
          sx={{
            p: 4,
            backgroundColor: 'rgba(255, 255, 255, 0.9)',
            backdropFilter: 'blur(10px)',
            borderRadius: 2,
          }}
        >
          <Typography variant="h4" align="center" gutterBottom sx={{ fontWeight: 'bold', color: '#1a237e' }}>
            Create Account
          </Typography>
          
          {error && (
            <Typography color="error" align="center" sx={{ mb: 2 }}>
              {error}
            </Typography>
          )}

          <form onSubmit={handleSubmit}>
            <TextField
              label="Email"
              type="email"
              required
              fullWidth
              margin="normal"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
            <TextField
              label="Password"
              type="password"
              required
              fullWidth
              margin="normal"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
            <TextField
              label="Confirm Password"
              type="password"
              required
              fullWidth
              margin="normal"
              value={passwordConfirm}
              onChange={(e) => setPasswordConfirm(e.target.value)}
            />
            <Button
              type="submit"
              fullWidth
              variant="contained"
              disabled={loading}
              sx={{
                mt: 3,
                mb: 2,
                background: 'linear-gradient(45deg, #6366F1 30%, #818CF8 90%)',
                color: 'white',
                '&:hover': {
                  background: 'linear-gradient(45deg, #4F46E5 30%, #6366F1 90%)',
                }
              }}
            >
              Sign Up
            </Button>
          </form>

          <Box sx={{ textAlign: 'center', mt: 2 }}>
            <Typography variant="body2">
              Already have an account?{' '}
              <Link to="/login" style={{ textDecoration: 'none' }}>
                <MuiLink component="span" sx={{ cursor: 'pointer' }}>
                  Log In
                </MuiLink>
              </Link>
            </Typography>
            <Typography variant="body2" sx={{ mt: 2 }}>
              Want more quizzes?{' '}
              <MuiLink 
                href="https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.freepik.com%2Ffree-vector%2Fquiz-background-with-flat-objects_1022603.htm&psig=AOvVaw2awps1Oh_SSa9k7rWETo1y&ust=1747329189596000&source=images&cd=vfe&opi=89978449&ved=0CBQQjRxqFwoTCIDtvc-6o40DFQAAAAAdAAAAABAE" 
                target="_blank" 
                rel="noopener noreferrer"
                sx={{ cursor: 'pointer' }}
              >
                Visit Quizizz
              </MuiLink>
            </Typography>
          </Box>
        </Paper>
      </Container>
    </Box>
  );
}

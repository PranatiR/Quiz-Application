import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import {
  Container,
  Grid,
  Card,
  CardContent,
  CardMedia,
  Typography,
  Button,
  Box,
  AppBar,
  Toolbar,
  Link as MuiLink,
} from '@mui/material';

const quizCategories = [
  {
    id: 'movies',
    title: 'Movies & Entertainment',
    description: 'Test your knowledge of films, TV shows, and pop culture',
    image: 'https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'sports',
    title: 'Sports Champions',
    description: 'Challenge yourself with questions about various sports',
    image: 'https://images.unsplash.com/photo-1461896836934-ffe607ba8211?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'gk',
    title: 'General Knowledge',
    description: 'Explore various topics from history to current affairs',
    image: 'https://images.unsplash.com/photo-1457369804613-52c61a468e7d?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'cs',
    title: 'Computer Science',
    description: 'Test your programming and tech knowledge',
    image: 'https://images.unsplash.com/photo-1517134191118-9d595e4c8c2b?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'math',
    title: 'Mathematics',
    description: 'Solve interesting math problems',
    image: 'https://images.unsplash.com/photo-1509228468518-180dd4864904?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'science',
    title: 'Science',
    description: 'Discover the wonders of science',
    image: 'https://images.unsplash.com/photo-1532094349884-543bc11b234d?auto=format&fit=crop&w=800&q=80'
  }
];

function Dashboard() {
  const { currentUser, logout } = useAuth();
  const navigate = useNavigate();
  const handleScore = () => {
  navigate('/history');
};
  const handleLogout = async () => {
    try {
      await logout();
      navigate('/login');
    } catch (error) {
      console.error('Failed to log out:', error);
    }
  };

  const startQuiz = (categoryId) => {
    navigate(`/quiz/${categoryId}`);
  };

  return (
    <Box 
      sx={{ 
        minHeight: '100vh',
        background: `linear-gradient(rgba(26, 35, 126, 0.9), rgba(49, 27, 146, 0.9)), url('https://images.unsplash.com/photo-1557683316-973673baf926?auto=format&fit=crop&w=1920&q=80')`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundAttachment: 'fixed',
        pt: 8,
        pb: 6,
      }}
      className="pattern-grid"
    >
      <AppBar 
        position="fixed" 
        sx={{ 
          background: 'rgba(255, 255, 255, 0.1)',
          backdropFilter: 'blur(10px)',
          boxShadow: '0 4px 30px rgba(0, 0, 0, 0.1)',
        }}
      >
        <Toolbar>
          <Typography variant="h6" component="div" sx={{ flexGrow: 1, fontWeight: 'bold', color: 'white' }}>
            Quiz Master
          </Typography>
          <Typography onClick={handleScore} variant="body1" sx={{ mr: 2, color: 'white' }}>
            {currentUser?.email}
          </Typography>
          
          <Button 
            color="inherit" 
            onClick={handleLogout}
            sx={{
              borderRadius: 25,
              px: 3,
              border: '1px solid white',
              '&:hover': {
                background: 'rgba(255, 255, 255, 0.1)',
              }
            }}
          >
            Logout
          </Button>
        </Toolbar>
      </AppBar>

      <Container maxWidth="lg" sx={{ mt: 4 }}>
        <Box sx={{ mb: 6, textAlign: 'center' }}>
          <Typography variant="h3" gutterBottom sx={{ fontWeight: 'bold', color: 'white' }}>
            Choose Your Challenge
          </Typography>
          <Typography variant="h6" sx={{ color: 'rgba(255, 255, 255, 0.8)', mb: 3 }}>
            Test your knowledge in various categories
          </Typography>
          <MuiLink 
            href="https://quizizz.com/?lng=en" 
            target="_blank" 
            rel="noopener noreferrer"
            sx={{ 
              color: '#818CF8',
              textDecoration: 'none',
              '&:hover': {
                textDecoration: 'underline'
              }
            }}
          >
            Explore more quizzes on Quizizz →
          </MuiLink>
        </Box>

        <Grid container spacing={4}>
          {quizCategories.map((category) => (
            <Grid item xs={12} sm={6} md={4} key={category.id}>
              <Card 
                sx={{ 
                  height: '100%',
                  display: 'flex',
                  flexDirection: 'column',
                  backgroundColor: 'rgba(255, 255, 255, 0.9)',
                  transition: 'transform 0.2s',
                  '&:hover': {
                    transform: 'translateY(-8px)',
                  }
                }}
              >
                <CardMedia
                  component="img"
                  height="200"
                  image={category.image}
                  alt={category.title}
                  sx={{ 
                    objectFit: 'cover',
                    borderBottom: '1px solid rgba(0,0,0,0.1)'
                  }}
                />
                <CardContent sx={{ flexGrow: 1, display: 'flex', flexDirection: 'column' }}>
                  <Typography variant="h5" component="h2" gutterBottom sx={{ fontWeight: 'bold', color: '#1a237e' }}>
                    {category.title}
                  </Typography>
                  <Typography variant="body1" color="text.secondary" sx={{ mb: 2, flexGrow: 1 }}>
                    {category.description}
                  </Typography>
                  <Button
                    variant="contained"
                    fullWidth
                    onClick={() => startQuiz(category.id)}
                    sx={{
                      mt: 'auto',
                      background: 'linear-gradient(45deg, #6366F1 30%, #818CF8 90%)',
                      color: 'white',
                      '&:hover': {
                        background: 'linear-gradient(45deg, #4F46E5 30%, #6366F1 90%)',
                      }
                    }}
                  >
                    Start Quiz
                  </Button>
                </CardContent>
              </Card>
            </Grid>
          ))}
        </Grid>
      </Container>
    </Box>
  );
}

export default Dashboard;

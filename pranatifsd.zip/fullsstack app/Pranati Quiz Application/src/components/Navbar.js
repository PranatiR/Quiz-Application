import React from 'react';
import { AppBar, Toolbar, Typography, Button, Box } from '@mui/material';
import { Link } from 'react-router-dom';

export default function NavBar() {
  return (
    <AppBar position="static" color="transparent" elevation={0} sx={{ borderBottom: '1px solid #eee' }}>
      <Toolbar sx={{ justifyContent: 'space-between' }}>
        
        {/* Left: App Name */}
        <Typography 
          variant="h6" 
          component={Link} 
          to="/dashboard" 
          sx={{ 
            textDecoration: 'none', 
            color: '#4F46E5', 
            fontWeight: 'bold',
            fontSize: '1.8rem'
          }}
        >
          Nimble Ben
        </Typography>

        {/* Center: Navigation Links */}
        <Box sx={{ display: 'flex', gap: 3 }}>
          <Button component={Link} to="/dashboard" color="inherit">Dashboard</Button>
          <Button component={Link} to="/history" color="inherit">History</Button>
          <Button component={Link} to="/profile" color="inherit">Profile</Button>
        </Box>

        {/* Right: Auth Buttons */}
        <Box sx={{ display: 'flex', gap: 2 }}>
          <Button 
            component={Link} 
            to="/login" 
            variant="outlined" 
            sx={{ borderColor: '#4F46E5', color: '#4F46E5' }}
          >
            Log In
          </Button>
          <Button 
            component={Link} 
            to="/signup" 
            variant="contained" 
            sx={{ backgroundColor: '#4F46E5', color: '#fff' }}
          >
            Sign Up
          </Button>
        </Box>
      </Toolbar>
    </AppBar>
  );
}

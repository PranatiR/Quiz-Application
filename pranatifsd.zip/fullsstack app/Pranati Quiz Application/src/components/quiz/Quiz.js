import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios'
import {
  Container,
  Paper,
  Typography,
  Button,
  Radio,
  RadioGroup,
  FormControlLabel,
  FormControl,
  LinearProgress,
  Box,
  Card,
  CardContent,
  img
} from '@mui/material';

const quizData = {
  movies: [
    {
      question: "Which film won the Academy Award for Best Picture in 2024?",
      options: ["Oppenheimer", "Barbie", "Poor Things", "Killers of the Flower Moon"],
      correctAnswer: 0,
      image: "https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?auto=format&fit=crop&w=800&q=80"
    },
    {
      question: "Who played Tony Stark/Iron Man in the Marvel Cinematic Universe?",
      options: ["Chris Evans", "Robert Downey Jr.", "Chris Hemsworth", "Mark Ruffalo"],
      correctAnswer: 1,
      image: "https://images.unsplash.com/photo-1635805737707-575885ab0820?auto=format&fit=crop&w=800&q=80"
    },
    {
      question: "What is the highest-grossing film of all time?",
      options: ["Avatar", "Avengers: Endgame", "Titanic", "Star Wars: Episode VII"],
      correctAnswer: 0,
      image: "https://images.unsplash.com/photo-1518676590629-3dcbd9c5a5c9?auto=format&fit=crop&w=800&q=80"
    },
    {
      question: "Which animated movie features a character named Woody?",
      options: ["Shrek", "Toy Story", "Finding Nemo", "The Lion King"],
      correctAnswer: 1,
      image: "https://images.unsplash.com/photo-1584824486509-112e4181ff6b?auto=format&fit=crop&w=800&q=80"
    },
    {
      question: "Who directed the movie Inception?",
      options: ["Steven Spielberg", "Christopher Nolan", "Martin Scorsese", "James Cameron"],
      correctAnswer: 1,
      image: "https://images.unsplash.com/photo-1440404653325-ab127d49abc1?auto=format&fit=crop&w=800&q=80"
    }
  ],
  sports: [
    {
      question: "Which country won the ICC Cricket World Cup 2023?",
      options: ["India", "Australia", "England", "New Zealand"],
      correctAnswer: 1,
      image: "https://images.unsplash.com/photo-1531415074968-036ba1b575da?auto=format&fit=crop&w=800&q=80"
    },
    {
      question: "Who holds the record for most goals in football/soccer?",
      options: ["Lionel Messi", "Cristiano Ronaldo", "Pelé", "Diego Maradona"],
      correctAnswer: 1,
      image: "https://images.unsplash.com/photo-1579952363873-27f3bade9f55?auto=format&fit=crop&w=800&q=80"
    },
    {
      question: "Which team has won the most NBA championships?",
      options: ["Los Angeles Lakers", "Boston Celtics", "Chicago Bulls", "Golden State Warriors"],
      correctAnswer: 1,
      image: "https://images.unsplash.com/photo-1546519638-68e109498ffc?auto=format&fit=crop&w=800&q=80"
    },
    {
      question: "In which sport would you perform a slam dunk?",
      options: ["Football", "Basketball", "Tennis", "Cricket"],
      correctAnswer: 1,
      image: "https://images.unsplash.com/photo-1546519638-68e109498ffc?auto=format&fit=crop&w=800&q=80"
    },
    {
      question: "Who has won the most Grand Slam tennis titles in men's singles?",
      options: ["Roger Federer", "Rafael Nadal", "Novak Djokovic", "Pete Sampras"],
      correctAnswer: 2,
      image: "https://images.unsplash.com/photo-1531315630201-bb15abeb1653?auto=format&fit=crop&w=800&q=80"
    }
  ],
  gk: [
    {
      question: "What is the capital of Japan?",
      options: ["Seoul", "Beijing", "Tokyo", "Bangkok"],
      correctAnswer: 2,
      image: "https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?auto=format&fit=crop&w=800&q=80"
    },
    {
      question: "Which is the largest planet in our solar system?",
      options: ["Mars", "Saturn", "Jupiter", "Neptune"],
      correctAnswer: 2,
      image: "https://images.unsplash.com/photo-1614732414444-096e5f1122d5?auto=format&fit=crop&w=800&q=80"
    },
    {
      question: "Who painted the Mona Lisa?",
      options: ["Vincent van Gogh", "Pablo Picasso", "Leonardo da Vinci", "Michelangelo"],
      correctAnswer: 2,
      image: "https://images.unsplash.com/photo-1544273677-c433136021d4?auto=format&fit=crop&w=800&q=80"
    },
    {
      question: "What is the chemical symbol for gold?",
      options: ["Ag", "Au", "Fe", "Cu"],
      correctAnswer: 1,
      image: "https://images.unsplash.com/photo-1610375461246-83df859d849d?auto=format&fit=crop&w=800&q=80"
    },
    {
      question: "Which is the largest ocean on Earth?",
      options: ["Atlantic Ocean", "Indian Ocean", "Pacific Ocean", "Arctic Ocean"],
      correctAnswer: 2,
      image: "https://images.unsplash.com/photo-1439405326854-014607f694d7?auto=format&fit=crop&w=800&q=80"
    }
  ],
  cs: [
    {
      question: "What does CPU stand for?",
      options: ["Central Processing Unit", "Computer Personal Unit", "Central Program Utility", "Computer Processing Unit"],
      correctAnswer: 0,
      image: "https://images.unsplash.com/photo-1591370874773-6702e8f12fd8?auto=format&fit=crop&w=800&q=80"
    },
    {
      question: "Which programming language is known as the 'mother of all languages'?",
      options: ["Java", "C", "Python", "FORTRAN"],
      correctAnswer: 1,
      image: "https://images.unsplash.com/photo-1515879218367-8466d910aaa4?auto=format&fit=crop&w=800&q=80"
    },
    {
      question: "What does HTML stand for?",
      options: ["Hyper Text Markup Language", "High Tech Modern Language", "Hyper Transfer Markup Language", "Home Tool Markup Language"],
      correctAnswer: 0,
      image: "https://images.unsplash.com/photo-1542831371-29b0f74f9713?auto=format&fit=crop&w=800&q=80"
    },
    {
      question: "Which company developed JavaScript?",
      options: ["Microsoft", "Netscape", "Apple", "Google"],
      correctAnswer: 1,
      image: "https://images.unsplash.com/photo-1627398242454-45a1465c2479?auto=format&fit=crop&w=800&q=80"
    },
    {
      question: "What is the main function of an operating system?",
      options: [
        "Manage hardware and software resources",
        "Play games",
        "Browse the internet",
        "Create documents"
      ],
      correctAnswer: 0,
      image: "https://images.unsplash.com/photo-1518432031352-d6fc5c10da5a?auto=format&fit=crop&w=800&q=80"
    }
  ],
  math: [
    {
      question: "What is 7 x 8?",
      options: ["54", "56", "58", "60"],
      correctAnswer: 1,
      image: "https://images.unsplash.com/photo-1596495578065-6e0763fa1178?auto=format&fit=crop&w=800&q=80"
    },
    {
      question: "What is the square root of 144?",
      options: ["10", "12", "14", "16"],
      correctAnswer: 1,
      image: "https://images.unsplash.com/photo-1635070041078-e363dbe005cb?auto=format&fit=crop&w=800&q=80"
    },
    {
      question: "What is 15% of 200?",
      options: ["20", "25", "30", "35"],
      correctAnswer: 2,
      image: "https://images.unsplash.com/photo-1509228468518-180dd4864904?auto=format&fit=crop&w=800&q=80"
    },
    {
      question: "If x + 5 = 12, what is x?",
      options: ["5", "6", "7", "8"],
      correctAnswer: 2,
      image: "https://images.unsplash.com/photo-1635070041078-e363dbe005cb?auto=format&fit=crop&w=800&q=80"
    },
    {
      question: "What is the area of a square with sides of length 9?",
      options: ["72", "81", "90", "99"],
      correctAnswer: 1,
      image: "https://images.unsplash.com/photo-1509228468518-180dd4864904?auto=format&fit=crop&w=800&q=80"
    }
  ],
  science: [
    {
      question: "What is the chemical formula for water?",
      options: ["CO2", "H2O", "O2", "N2"],
      correctAnswer: 1,
      image: "https://images.unsplash.com/photo-1583950709786-0fddcb56c880?auto=format&fit=crop&w=800&q=80"
    },
    {
      question: "Which planet is known as the Red Planet?",
      options: ["Venus", "Mars", "Jupiter", "Saturn"],
      correctAnswer: 1,
      image: "https://images.unsplash.com/photo-1614732414444-096e5f1122d5?auto=format&fit=crop&w=800&q=80"
    },
    {
      question: "What is the largest organ in the human body?",
      options: ["Heart", "Brain", "Liver", "Skin"],
      correctAnswer: 3,
      image: "https://images.unsplash.com/photo-1576086213369-97a306d36557?auto=format&fit=crop&w=800&q=80"
    },
    {
      question: "What is the process by which plants make their food?",
      options: ["Photosynthesis", "Respiration", "Digestion", "Absorption"],
      correctAnswer: 0,
      image: "https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?auto=format&fit=crop&w=800&q=80"
    },
    {
      question: "What is the atomic number of oxygen?",
      options: ["6", "7", "8", "9"],
      correctAnswer: 2,
      image: "https://images.unsplash.com/photo-1532187863486-abf9dbad1b69?auto=format&fit=crop&w=800&q=80"
    }
  ]
};

export default function Quiz() {
  const { category } = useParams();
  const navigate = useNavigate();
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [score, setScore] = useState(0);
  const [showScore, setShowScore] = useState(false);
  const [selectedOption, setSelectedOption] = useState(null);
  const questions = quizData[category] || [];

  const handleDashboard=async(e)=>{
    e.preventDefault();
    try{
      const storedUser = localStorage.getItem("user");
      console.log("ttttttt");
    if (!storedUser) {
      console.error("User not logged in.");
      return;
    }
    console.log("vvvvvvvv");
    const user = JSON.parse(storedUser);
    const uemail = user.email; 
    console.log("yyyyyyyyy");
      const res= await axios.post("http://localhost:4000/storeResult",{
      email:uemail,
      category:category,
      score:score,
      totalQuestions:questions.length,
            })
            console.log("kkkkkkk");
            // console.log(res.data)
            if(res.data.isvalid){
                alert("score stored !!!!");
                navigate("/dashboard");
            }
            else{
                alert("score can't stored!")
            }
    }catch(e){
      console.log("can't stored"+e);
    }
  }

  const handleAnswerSubmit = () => {
    if (selectedOption === questions[currentQuestion].correctAnswer) {
      setScore(score + 1);
    }

    const nextQuestion = currentQuestion + 1;
    if (nextQuestion < questions.length) {
      setCurrentQuestion(nextQuestion);
      setSelectedOption(null);
    } else {
      setShowScore(true);
    }
  };

  const handleRetry = async() => {
    setCurrentQuestion(0);
    setScore(0);
    setShowScore(false);
    setSelectedOption(null);
    try{
    const storedUser = localStorage.getItem("user");
    if (!storedUser) {
      console.error("User not logged in.");
      return;
    }
    const user = JSON.parse(storedUser);
    const uemail = user.email; 
      const res= await axios.post("http://localhost:4000/storeResult",{
      email:uemail,
      category:category,
      score:score,
      totalQuestions:questions.length,
            })
            console.log(res.data)
            if(res.data.isvalid){
                alert("score stored !!!!");
            }
            else{
                alert("score can't stored!")
            }
    }catch(e){
      console.log("can't stored"+e);
    }
  };

  if (!questions.length) {
    return (
      <Container maxWidth="sm" sx={{ mt: 4 }}>
        <Typography variant="h5" align="center">
          Category not found
        </Typography>
      </Container>
    );
  }

  if (showScore) {
    return (
      <Container maxWidth="sm" sx={{ mt: 4 }}>
        <Card elevation={3}>
          <CardContent>
            <Typography variant="h4" align="center" gutterBottom>
              Quiz Completed!
            </Typography>
            <Typography variant="h5" align="center" gutterBottom>
              Your Score: {score} out of {questions.length}
            </Typography>
            <Typography variant="body1" align="center" gutterBottom>
              Percentage: {((score / questions.length) * 100).toFixed(2)}%
            </Typography>
            <Box sx={{ mt: 3, display: 'flex', justifyContent: 'center', gap: 2 }}>
              <Button variant="contained"  onClick={handleRetry}>
                Try Again
              </Button>
              <Button variant="outlined"  onClick={handleDashboard}>
                Back to Dashboard
              </Button>
            </Box>
          </CardContent>
        </Card>
      </Container>
    );
  }

  return (
    <Container maxWidth="md" sx={{ mt: 4, mb: 6 }}>
      <Paper elevation={3} sx={{ p: 4, borderRadius: 3 }}>
        <Box sx={{ mb: 3 }}>
          <LinearProgress
            variant="determinate"
            value={(currentQuestion / questions.length) * 100}
            sx={{
              height: 10,
              borderRadius: 5,
              backgroundColor: 'rgba(99, 102, 241, 0.1)',
              '& .MuiLinearProgress-bar': {
                borderRadius: 5,
              },
            }}
          />
          <Typography variant="h6" sx={{ mt: 2, color: 'text.secondary' }}>
            Question {currentQuestion + 1} of {questions.length}
          </Typography>
        </Box>

        {questions[currentQuestion].image && (
          <Box sx={{ mb: 4, borderRadius: 2, overflow: 'hidden', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}>
            <img
              src={questions[currentQuestion].image}
              alt="Question"
              style={{
                width: '100%',
                height: '300px',
                objectFit: 'cover',
              }}
            />
          </Box>
        )}

        <Typography variant="h5" gutterBottom sx={{ mb: 4, fontWeight: 'bold' }}>
          {questions[currentQuestion].question}
        </Typography>

        <FormControl component="fieldset" sx={{ width: '100%' }}>
          <RadioGroup
            value={selectedOption}
            onChange={(e) => setSelectedOption(parseInt(e.target.value))}
          >
            {questions[currentQuestion].options.map((option, index) => (
              <FormControlLabel
                key={index}
                value={index}
                control={<Radio />}
                label={option}
                className="quiz-option"
                sx={{
                  mb: 2,
                  p: 2,
                  border: 1,
                  borderColor: selectedOption === index ? 'primary.main' : 'grey.300',
                  borderRadius: 2,
                  transition: 'all 0.3s ease',
                }}
              />
            ))}
          </RadioGroup>
        </FormControl>

        <Box sx={{ mt: 4, display: 'flex', justifyContent: 'space-between' }}>
          <Button
            variant="outlined"
            onClick={() => navigate('/dashboard')}
            sx={{ borderRadius: 25, px: 4 }}
          >
            Quit Quiz
          </Button>
          <Button
            variant="contained"
            onClick={handleAnswerSubmit}
            disabled={selectedOption === null}
            sx={{ borderRadius: 25, px: 4 }}
          >
            {currentQuestion === questions.length - 1 ? 'Finish' : 'Next Question'}
          </Button>
        </Box>
      </Paper>
    </Container>
  );
}

import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useAuth } from '../contexts/AuthContext';
import {
  Container,
  Typography,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  CircularProgress
} from '@mui/material';

function QuizHistory() {
  const { currentUser } = useAuth();
  const [quizResults, setQuizResults] = useState([]);
  const [loading, setLoading] = useState(true);

useEffect(() => {
  const fetchQuizResults = async () => {
    if (currentUser?.email) {
      try {
        const res = await axios.get(`http://localhost:4000/quiz-results?email=${currentUser.email}`);
        
        setLoading(false);
        setQuizResults(res.data);
      } catch (e) {
        console.error("Can't fetch quiz history:", e);
      }
    }
  }

  fetchQuizResults();
}, [currentUser]);

  return (
    <Container sx={{ mt: 10 }}>
      <Typography variant="h4" gutterBottom>
        Quiz History
      </Typography>

      {loading ? (
        <CircularProgress />
      ) : (
        <TableContainer component={Paper}>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Category</TableCell>
                <TableCell>Score</TableCell>
                <TableCell>Total Questions</TableCell>
                <TableCell>Percentage</TableCell>
                <TableCell>Date</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {quizResults.map((result, index) => (
                <TableRow key={index}>
                  <TableCell>{result.category}</TableCell>
                  <TableCell>{result.score}</TableCell>
                  <TableCell>{result.totalQuestions}</TableCell>
                  <TableCell>{result.percentage}%</TableCell>
                  <TableCell>{new Date(result.date).toLocaleString()}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      )}
    </Container>
  );
}

export default QuizHistory;

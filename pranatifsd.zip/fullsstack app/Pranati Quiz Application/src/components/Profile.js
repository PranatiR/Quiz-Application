import React from 'react';
import { useAuth } from '../contexts/AuthContext';
import { Container, Card } from 'react-bootstrap';

export default function Profile() {
  const { currentUser } = useAuth();

  return (
    <Container className="d-flex align-items-center justify-content-center" style={{ minHeight: "100vh" }}>
      <div className="w-100" style={{ maxWidth: "400px" }}>
        <Card>
          <Card.Body>
            <h2 className="text-center mb-4">Profile</h2>
            <div className="text-center">
              <p><strong>Email:</strong> {currentUser?.email}</p>
              <p><strong>Score:</strong> {currentUser?.score || 0}</p>
            </div>
          </Card.Body>
        </Card>
      </div>
    </Container>
  );
}

import React, { createContext, useState, useContext, useEffect } from 'react';

const AuthContext = createContext();

export function useAuth() {
  return useContext(AuthContext);
}

export function AuthProvider({ children }) {
  const [currentUser, setCurrentUser] = useState(() => {
    const user = localStorage.getItem('user');
    return user ? JSON.parse(user) : null;
  });

  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(false);
  }, []);

  function signup(email, password) {
    return new Promise((resolve) => {
      const user = { email, password, score: 0 };
      localStorage.setItem('user', JSON.stringify(user));
      setCurrentUser(user);
      resolve(user);
    });
  }

  function login(email, password) {
    return new Promise((resolve, reject) => {
      if (email && password.length >= 6) {
        const user = { email, score: 0 };
        localStorage.setItem('user', JSON.stringify(user));
        setCurrentUser(user);
        resolve(user);
      } else {
        reject(new Error('Invalid credentials'));
      }
    });
  }

  function logout() {
    return new Promise((resolve) => {
      localStorage.removeItem('user');
      setCurrentUser(null);
      resolve();
    });
  }

  function updateScore(newScore) {
    return new Promise((resolve) => {
      const updatedUser = { ...currentUser, score: newScore };
      localStorage.setItem('user', JSON.stringify(updatedUser));
      setCurrentUser(updatedUser);
      resolve(updatedUser);
    });
  }

  const value = {
    currentUser,
    signup,
    login,
    logout,
    updateScore
  };

  return (
    <AuthContext.Provider value={value}>
      {!loading && children}
    </AuthContext.Provider>
  );
}

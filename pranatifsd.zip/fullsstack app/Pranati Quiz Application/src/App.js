import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { ThemeProvider, createTheme } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';

import Login from './components/auth/Login';
import SignUp from './components/auth/SignUp';
import Dashboard from './components/Dashboard';
import Quiz from './components/quiz/Quiz';
import Profile from './components/Profile';
import QuizHistory from './components/QuizHistory';
import { AuthProvider } from './contexts/AuthContext';

import Navbar from './components/Navbar';  // make sure the filename is Navbar.js

const theme = createTheme({
  palette: {
    primary: {
      main: '#6366F1',
      light: '#818CF8',
      dark: '#4F46E5',
    },
    secondary: {
      main: '#EC4899',
      light: '#F472B6',
      dark: '#DB2777',
    },
    background: {
      default: '#F1F5F9',
      paper: '#FFFFFF',
    },
    gradient: {
      main: 'linear-gradient(135deg,rgb(17, 209, 235) 0%, #818CF8 100%)',
      secondary: 'linear-gradient(135deg, #EC4899 0%, #F472B6 100%)',
      dark: 'linear-gradient(135deg, #1E293B 0%, #334155 100%)',
    },
  },
  typography: {
    fontFamily: '"Poppins","Roboto", "Helvetica", "Arial", sans-serif',
    h1: { fontWeight: 700 },
    h2: { fontWeight: 700 },
    h3: { fontWeight: 600 },
    h4: { fontWeight: 600 },
  },
  shape: { borderRadius: 16 },
  components: {
    MuiButton: {
      styleOverrides: {
        root: {
          borderRadius: 30,
          textTransform: 'none',
          fontSize: '1rem',
          padding: '12px 24px',
          boxShadow: '0 4px 6px -1px rgba(99, 102, 241, 0.2)',
        },
      },
    },
    MuiCard: {
      styleOverrides: {
        root: {
          borderRadius: 20,
          boxShadow: '0 10px 20px rgba(99, 102, 241, 0.1)',
        },
      },
    },
  },
});

function App() {
  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <AuthProvider>
        <Navbar /> {/* Include Navbar here */}
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/signup" element={<SignUp />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/quiz/:category" element={<Quiz />} />
          <Route path="/profile" element={<Profile />} />
          <Route path="/" element={<Navigate to="/login" />} />
          <Route path="/history" element={<QuizHistory />} />
        </Routes>
      </AuthProvider>
    </ThemeProvider>
  );
}

export default App;
